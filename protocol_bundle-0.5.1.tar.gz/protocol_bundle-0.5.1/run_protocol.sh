#!/bin/sh
set -e

##----------------------------------------------------------
## Scalpel resource bundle for variant calling and analysis
##----------------------------------------------------------
## version: v0.5.1
## Authors: Han Fang, Giuseppe Narzisi, Michael C. Schatz
## Date: June 23, 2015
##----------------------------------------------------------


##--------------------------------
## download and set up files/tools
##--------------------------------
## 1|Download the example sequencing reads of the Hapmap quad family from the Illumina Platinum Genome project (*_1*fastq.gz and *_2*fastq.gz denote paired end reads):
wget --no-check ftp://ftp.sra.ebi.ac.uk/vol1/fastq/ERR194/ERR194146/ERR194146_1.fastq.gz
wget --no-check ftp://ftp.sra.ebi.ac.uk/vol1/fastq/ERR194/ERR194146/ERR194146_2.fastq.gz
wget --no-check ftp://ftp.sra.ebi.ac.uk/vol1/fastq/ERR194/ERR194147/ERR194147_1.fastq.gz
wget --no-check ftp://ftp.sra.ebi.ac.uk/vol1/fastq/ERR194/ERR194147/ERR194147_2.fastq.gz
wget --no-check ftp://ftp.sra.ebi.ac.uk/vol1/fastq/ERR194/ERR194151/ERR194151_1.fastq.gz
wget --no-check ftp://ftp.sra.ebi.ac.uk/vol1/fastq/ERR194/ERR194151/ERR194151_2.fastq.gz
wget --no-check ftp://ftp.sra.ebi.ac.uk/vol1/fastq/ERR324/ERR324432/ERR324432_1.fastq.gz
wget --no-check ftp://ftp.sra.ebi.ac.uk/vol1/fastq/ERR324/ERR324432/ERR324432_2.fastq.gz

## 2|Download the human reference genome hg19:
wget --no-check http://hgdownload.cse.ucsc.edu/goldenPath/hg19/bigZips/hg19.2bit
wget --no-check http://hgdownload.cse.ucsc.edu/admin/exe/linux.x86_64/twoBitToFa

## 3|Convert the *.2bit genome to *.fa format and index it with bwa (Note you can also download the fasta file directly, although may take much longer):
chmod +x twoBitToFa ; ./twoBitToFa hg19.2bit hg19.fa
bwa index hg19.fa

##--------------------------------
## Align the NGS reads to the genome
##--------------------------------
## 4|Align reads to reference for each sample separately with bwa mem:
bwa mem -t 10 hg19.fa ERR194146_1.fastq.gz ERR194146_2.fastq.gz | samtools view -h -S -b > NA12877.bam
bwa mem -t 10 hg19.fa ERR194147_1.fastq.gz ERR194147_2.fastq.gz | samtools view -h -S -b > NA12878.bam
bwa mem -t 10 hg19.fa ERR324432_1.fastq.gz ERR324432_2.fastq.gz | samtools view -h -S -b > NA12881.bam
bwa mem -t 10 hg19.fa ERR194151_1.fastq.gz ERR194151_2.fastq.gz | samtools view -h -S -b > NA12882.bam

## 5|Sort the bam files by chromosome coordinates with samtools:
samtools sort -m 4G NA12877.bam NA12877.sort
samtools sort -m 4G NA12878.bam NA12878.sort
samtools sort -m 4G NA12881.bam NA12881.sort
samtools sort -m 4G NA12882.bam NA12882.sort
rm -f NA12877.bam NA12878.bam NA12881.bam NA12882.bam 

## 6|Mark duplicated reads within the alignment with picard tools:
java -jar -Xmx10g picard MarkDuplicates INPUT=NA12877.sort.bam OUTPUT=NA12877.sort.markdup.bam METRICS_FILE=NA12877.sort.metric
java -jar -Xmx10g picard MarkDuplicates INPUT=NA12878.sort.bam OUTPUT=NA12878.sort.markdup.bam METRICS_FILE=NA12878.sort.metric
java -jar -Xmx10g picard MarkDuplicates INPUT=NA12881.sort.bam OUTPUT=NA12881.sort.markdup.bam METRICS_FILE=NA12881.sort.metric
java -jar -Xmx10g picard MarkDuplicates INPUT=NA12882.sort.bam OUTPUT=NA12882.sort.markdup.bam METRICS_FILE=NA12882.sort.metric
rm -f NA12877.sort.bam NA12878.sort.bam NA12881.sort.bam NA12882.sort.bam

## 7|Perform a basic quality control of the alignment files with samtools:
samtools flagstat NA12877.sort.markdup.bam > NA12877.sort.markdup.bam.simplestats
samtools flagstat NA12878.sort.markdup.bam > NA12878.sort.markdup.bam.simplestats
samtools flagstat NA12881.sort.markdup.bam > NA12881.sort.markdup.bam.simplestats
samtools flagstat NA12882.sort.markdup.bam > NA12882.sort.markdup.bam.simplestats

##--------------------------------
## Perform indel variant calling and downstream filtering
##--------------------------------
## 8|Run Scalpel in the “de novo” mode to perform multi-sample calling for a family. In this example, we use NA12882 as the affected individual. The NA12881 is the unaffected individual accordingly:
scalpel --denovo --dad NA12877.sort.markdup.bam --mom NA12878.sort.markdup.bam --aff NA12882.sort.markdup.bam –sib NA12881.sort.markdup.bam --bed SeqCap_EZ_Exome_v3_primary.scalpel.bed --ref hg19.fa --numprocs 10 --two-pass

## 9|Export the inherited and denovo mutations from the Scalpel database (in target only):
scalpel --export --db outdir/main/inherited.db --bed SeqCap_EZ_Exome_v3_primary.scalpel.bed --ref hg19.fa --intarget > inherited.onepass.vcf
scalpel --export --db outdir/twopass/denovos.db --bed SeqCap_EZ_Exome_v3_primary.scalpel.bed --ref hg19.fa --intarget > denovo.twopass.vcf

## 10|Identify and mark indels within STR regions using ms-detector:
sh ./msdetector/msdetector.sh -r 50 -d 2 -g hg19.fa -i inherited.onepass.vcf > inherited.onepass.vcf.ms
sh ./msdetector/msdetector.sh -r 50 -d 2 -g hg19.fa -i denovo.twopass.vcf    > denovo.twopass.vcf.ms

## 11|Save indels within and outside STR regions into different vcf files:
cat inherited.onepass.vcf.ms | awk -F "\t" '{if($0 ~ /^#/){print $0} else{if($13=="yes") print} }' | cut -d\t -f1-10 > inherited.onepass.vcf.ms.in
cat inherited.onepass.vcf.ms | awk -F "\t" '{if($0 ~ /^#/){print $0} else{if($13=="no") print} }' | cut -d\t -f1-10  > inherited.onepass.vcf.ms.out
cat denovo.twopass.vcf.ms | awk -F "\t" '{if($0 ~ /^#/){print $0} else{if($13=="yes") print} }' | cut -d\t -f1-10 > denovo.twopass.vcf.ms.in
cat denovo.twopass.vcf.ms | awk -F "\t" '{if($0 ~ /^#/){print $0} else{if($13=="no") print} }' | cut -d\t -f1-10 > denovo.twopass.vcf.ms.out

## 12|Filter out false positive calls by adjusting coverage and/or chi-squared thresholds for your data:
sh filter_vcf.sh -i inherited.onepass.vcf.ms.out -a 10 -c 10.8 -f 0 -m 0 > inherited.onepass.vcf.ms.out.hq
sh filter_vcf.sh -i denovo.twopass.vcf.ms.out -a 10 -c 10.8 -f 20 -m 20 > denovo.twopass.vcf.ms.out.hq

## 13|(Optional) Extract a subset of indels based on other annotation using bedtools:
bedtools intersect -wa -u -a inherited.onepass.vcf.ms.out.hq -b clinvar_main.bed > inherited.onepass.vcf.ms.out.hq.clinvar

## 14|Summarize indel calls with histogram of mutations by size.
grep -v "#" inherited.onepass.vcf.ms.out.hq denovo.twopass.vcf.ms.out.hq | awk '{print length($5)-length($4)}' > all.indel.size 
gnuplot44 -e "outfile='indel_size_dist.pdf'; infile='all.indel.size'" size_dist.pl

## 15|Summarize homopolymer indels calls with histogram of mutations by VAF.
## need one more script for generating the input txt files
## gnuplot44 -e "outfile='homo.vaf.pdf'; infileA='polyA.VAF.txt'; infileC='polyC.VAF.txt'; infileG='polyG.VAF.txt'; infileT='polyT.VAF.txt' " hp.vafdist.pl

## 16|Summarize inherited indels with variant allele frequencies (VAF %): 
cat inherited.onepass.vcf.ms.out    | awk -F'\t' '$0!~/^#/ {split($10,a,":"); split(a[2],b,","); print b[1] "\t" b[2]}' > inherited.onepass.vcf.ms.out.vaf
cat inherited.onepass.vcf.ms.out.hq | awk -F'\t' '$0!~/^#/ {split($10,a,":"); split(a[2],b,","); print b[1] "\t" b[2]}' > inherited.onepass.vcf.ms.out.hq.vaf
gnuplot44 -e "outfile='inherited.VAFdist.pdf'; infileAll='inherited.onepass.vcf.ms.out.vaf'; infileHq='inherited.onepass.vcf.ms.out.hq.vaf'" vafdistplot.inherited.qual.pl

## 17|Determine the number of indels remained after each step of the filtering:
for i in *.vcf.* ; do echo $i; grep -v "#" $i | wc -l ;done


##--------------------------------
## Annotation and visualization of the indel calls 
##--------------------------------
## 18|Prepare and create the input format required by ANNOVAR: 
# annovar=/path-to-annovar/
# $annovar/convert2annovar.pl -format vcf4 inherited.onepass.vcf.ms.out.hq > inherited.onepass.vcf.ms.out.hq.avinput
# $annovar/convert2annovar.pl -format vcf4 denovo.twopass.vcf.ms.out.hq > denovo.twopass.vcf.ms.out.hq.avinput

## 19|Annotate and intersect indels with gene regions using ANNOVAR
# $annovar/annotate_variation.pl -buildver hg19 inherited.onepass.vcf.ms.out.hq.avinput $annovar/humandb
# $annovar/annotate_variation.pl -buildver hg19 denovo.twopass.vcf.ms.out.hq.avinput $annovar/humandb

## 20|Summarize coding region indels by size in R.
# % R
# > indel=read.table("type_and_size.txt", header=FALSE)
# > colnames(indel)= c("type","size")
# > indel_30=indel[indel[,2]<=30,]
# > indel.table <- table(indel_30$type,factor(indel_30$size,lev=1:30)  )
# > pdf('rplot.pdf', width=12, height=8)
# > barplot(indel.table, main="indel distribution within coding sequence (CDS)", xlab="", col=c("green","red"), legend = rownames(indel.table))
# > dev.off()

## 21|Retrieve frame-shift mutations, which are potentially loss-of-function
cat inherited.onepass.vcf.ms.out.hq.avinput.exonic_variant_function | awk '{if($2=="frameshift") print}' > inherited.onepass.vcf.ms.out.hq.avinput.exonic_variant_function.frameshift
cat denovo.twopass.vcf.ms.out.hq.avinput.exonic_variant_function | awk '{if($2=="frameshift") print}' > denovo.twopass.vcf.ms.out.hq.avinput.exonic_variant_function.frameshift
