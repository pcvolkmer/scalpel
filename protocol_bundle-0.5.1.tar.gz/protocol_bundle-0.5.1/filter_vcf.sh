#!/bin/bash

#
# A wrapper for filtering Scalpel VCF files
#
# version 0.1.0 2015-06-22
# Han Fang (hanfang.cshl@gmail.com)
# Cold Spring Harbor Laboratory
#
# Currently it supports filtering based on alternative allele coverage, chi2 square score, father coverage, mother coverage

USAGE="Usage: `basename $0` [-hv] \n
\t -i <vcf>\t VCF file with list of variants \n
\t -a <aac>\t remove varaints whose alternative allele coverage is smaller than [INT], Default: 0 \n
\t -c <chi2>\t remove varaints whose chi2 square score is greater than [float], Default: 0 \n
\t -f <dadcov>\t remove varaints whose father coverage is smaller than [INT], Default: 0\n
\t -m <mumcov>\t remove varaints whose mother coverage is smaller than [INT], Default: 0\n"

usage()
{
    echo -e $USAGE >&2
    exit 1
}
MINCOV=0
CHI2=0
DADCOV=0
DADCOV=0

[ "$#" -lt 1 ] && usage

# Parse command line options.
while getopts hvi:a:c:f:m: OPT; do
        case "$OPT" in
                h)
                        echo $USAGE
                        exit 0
                        ;;
                v)
                        echo "`basename $0` version 0.1"
                        exit 0
                        ;;
                i)
                        varFileList=$OPTARG
                        ;;
                a)
                        MINCOV=$OPTARG
                        ;;
                c)
                        CHI2=$OPTARG
                        ;;
                f)
                        DADCOV=$OPTARG
                        ;;
                m)
                        MUMCOV=$OPTARG
                        ;;
                \?)
                        # getopts issues an error message
                        echo $USAGE >&2
                        exit 1
                        ;;
        esac
done

# Remove the options we parsed above.
shift `expr $OPTIND - 1`

# grab header
awk '$0~/^#/ {print}' $varFileList

# Begin awk script.
# -----------------------------
cat $varFileList | \
awk -F "[\t;=,/]" '{if ( ($11 >='"${MINCOV}"' || $19 <='"${CHI2}"') && ($26 >='"${DADCOV}"' && $27>='"${MUMCOV}"') ) print }' 